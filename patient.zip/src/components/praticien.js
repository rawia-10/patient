import React, { Component } from 'react';
class praticien extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( 
            <div>
                <div><h1>Welcome</h1> </div>
                <h1>Welcome</h1>
                
            </div>
         );
    }
}
 
export default praticien;