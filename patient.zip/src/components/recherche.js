import React, { Component } from 'react';
class recherche extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( 
            <div>
                
            </div>
         );
    }
}
 
export default recherche;