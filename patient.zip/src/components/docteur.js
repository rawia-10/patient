import React, { Component } from 'react';
class docteur extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( 
            <div>

            </div>
         );
    }
}
 
export default docteur;